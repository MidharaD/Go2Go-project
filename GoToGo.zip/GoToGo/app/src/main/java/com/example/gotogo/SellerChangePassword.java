package com.example.gotogo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SellerChangePassword extends AppCompatActivity {
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_change_password);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Change Password");

//        btn = findViewById(R.id.update);
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(getApplicationContext(),SellerMyProfile.class);
//                startActivity(i);
//            }
//        });

    }

    public void ShowMessage(View view) {
        Intent intent = new Intent(SellerChangePassword.this, PopUpScreen.class);
        intent.putExtra("custom_layout", R.layout.custom_toast);
        startActivity(intent);
    }
}