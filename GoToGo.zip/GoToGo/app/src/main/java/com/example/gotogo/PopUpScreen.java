package com.example.gotogo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class PopUpScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up_screen);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Go2Go");

        int customLayoutId = getIntent().getIntExtra("custom_layout", 0);
        LayoutInflater inflater = getLayoutInflater();
        View customToastLayout = inflater.inflate(customLayoutId, (ViewGroup) findViewById(R.id.toast_root));

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER,0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToastLayout);

        toast.show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(PopUpScreen.this,SellerMyProfile.class);
                startActivity(intent);
            }
        },5000);
    }
}