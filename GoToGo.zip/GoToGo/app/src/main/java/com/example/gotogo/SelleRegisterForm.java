package com.example.gotogo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;




public class SelleRegisterForm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selle_register_form);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Go2Go");

        //Spinner spinner = (Spinner) findViewById(R.id.spinner);
        //spinner.setTextColor(Color.parseColor("#FFFFFF"));


//        String[] value = {"Matara","Galle","Colombo","Nuwara","Monaragala"};
//        ArrayList<String> arrayList = new ArrayList<>(Arrays.asList(value));
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,R.layout.style_choosecity_spinner,arrayList);
//        spinner.setAdapter(arrayAdapter);

    }
}