package com.example.gotogo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

public class BuyerRegisterForm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_register_form);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Go2Go");

        Button myButton = (Button) findViewById(R.id.button);
        //myButton.setBackgroundColor(Color.parseColor("#666666"));
       // myButton.setBackgroundResource(R.drawable.button);
    }
}